@extends("layouts.base")
@section("title")

    martSNP- submit order successfully
@endsection

@section("content")


    <br>
    <br>
    <div  class="shadow-sm p-3 mb-5 bg-white rounded m-auto">
        Ordered Placed Successfully. Store Owner Will Contact You Soon About the Details
        </div>

    <br>
    <br>

@endsection
