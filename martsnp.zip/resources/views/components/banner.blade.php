<div class="p-b-32 m-t-60">
    <h3 class="ltext-105 cl5 txt-center respon1">
        STORES

    </h3>

    <div  style="height:30px;width:200px;color:black; margin-left: auto;margin-right: auto;">
        <hr>
    </div>
</div>

