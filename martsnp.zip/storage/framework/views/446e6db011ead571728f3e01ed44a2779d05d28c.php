<?php $__env->startSection("content"); ?>
    <div class="card">
        <div class="card-header font-24 text-danger">
            martSNP
        </div>
        <div class="card-body">




























            <div class="d-flex justify-content-around flex-wrap" >



                <?php if(auth()->user()->account_type === 'seller'): ?>

            <a href="<?php echo e(route("stores.index")); ?>" class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                <div class="icon">
                    <img src="https://img.icons8.com/dusk/128/000000/online-store.png"/>
                </div>
                 <h5 href="<?php echo e(route("stores.index")); ?>" class="text-success">My Store</h5>

            </a>






                <a href="<?php echo e(route("products.index")); ?>" class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                    <div class="icon">
                        <img src="https://img.icons8.com/flat_round/128/000000/add-tag--v1.png"/>
                    </div>
                    <h5   class="text-success">My Products</h5>

                </a>


                <a href="<?php echo e(route('orders.myorders')); ?>" class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                    <div class="icon">
                        <img src="https://img.icons8.com/nolan/128/order-history.png"/>
                    </div>
                    <h5   class="text-success">New Orders</h5>

                </a>
                    <a href="<?php echo e(route('subscription.index')); ?>"  class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                        <div class="icon">
                            <img src="https://img.icons8.com/cotton/128/000000/mobile-payment--v3.png"/>
                        </div>
                        <h5 href="<?php echo e(route("stores.index")); ?>" class="text-success">Subscription</h5>

                    </a>



                <?php else: ?>

                <form action="<?php echo e(route('seller.store')); ?>" method="POST">
                   <?php echo csrf_field(); ?>

                <button type="submit"   class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;background:transparent;border: none;">
                        <div class="icon">
                            <img src="https://img.icons8.com/color/128/000000/reseller.png"/>
                        </div>
                    <h5   class="text-success">Become A Seller</h5>

                </button>

                </form>



              <?php endif; ?>

                    <a  href="<?php echo e(route('orders.index')); ?>" class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                        <div class="icon">
                            <img src="https://img.icons8.com/dusk/128/000000/payment-history.png"/>
                        </div>
                        <h5   class="text-success">Your History</h5>

                    </a>


                    <a  href="<?php echo e(route("home")); ?>" class="shadow-sm p-3 m-10 bg-white rounded text-center font-24 " style="cursor:pointer;">
                        <div class="icon">
                            <img   src="https://img.icons8.com/dusk/128/000000/front-sorting.png"/>
                        </div>
                        <h5   class="text-success">Back to front page</h5>

                    </a>




            </div>




        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/dashboard/home.blade.php ENDPATH**/ ?>