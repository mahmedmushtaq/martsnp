<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header font-24">
            <?php echo e(isset($product) ? "Edit product" : "Add A New Product"); ?>

        </div>
        <div class="card-body">

            <?php echo $__env->make("partials.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(isset($product) ? route("products.update",$product->id) :route("products.store")); ?>" method="POST" enctype="multipart/form-data">
                <?php if(isset($product)): ?>
                    <?php echo method_field("PUT"); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Product Name</label>
                    <input type="text" class="form-control" placeholder="Product Name" name="product_name" value="<?php echo e(isset($product)? $product->product_name : ""); ?>">
                </div>


                    <div class="form-group">
                        <label for="">Product Price</label>
                        <input type="text" class="form-control" placeholder="Product Price" name="product_price" value="<?php echo e(isset($product)? $product->price : ""); ?>">
                    </div>

                    <div class="form-group">
                        <label for="">Product Size <small>(e.g small,medium,large)</small></label>
                        <input type="text" class="form-control" placeholder="Product size" name="product_size" value="<?php echo e(isset($product)? $product->product_size : ""); ?>">
                    </div>

                    <div class="form-group">
                        <label for="">Product Description</label>
                        <textarea  class="form-control" placeholder="Write the complete product description" name="product_description" ><?php echo e(isset($product)? $product->description : ""); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="">Product Category</label>
                        <select name="category_name" id="" class="form-control">



                                    <option value="male"
                                    <?php if(isset($product)): ?>
                                        <?php echo e($product->category_name === "male" ? 'selected' : ""); ?>

                                        <?php endif; ?>
                                    >Male</option>




                            <option value="female"
                            <?php if(isset($product)): ?>
                                <?php echo e($product->category_name === "female" ? 'selected' : ""); ?>

                                <?php endif; ?>
                            >Female</option>
                            <option value="both"
                            <?php if(isset($product)): ?>
                                <?php echo e($product->category_name === "both" ? 'selected' : ""); ?>

                                <?php endif; ?>
                            >Male and female</option>

                            <option value="other"
                            <?php if(isset($product)): ?>
                                <?php echo e($product->category_name === "both" ? 'selected' : ""); ?>

                                <?php endif; ?>
                            >Other categories</option>

                        </select>
                    </div>


                    <div class="form-group">
                        <label for="">Stores</label>
                        <select name="store_id" id="" class="form-control">
                            <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($store->id); ?>"
                              <?php if(isset($product)): ?>
                                  <?php echo e($product->store_id === $store->id ? 'selected' : ""); ?>

                              <?php endif; ?>
                              ><?php echo e($store->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>

                    <div class="form-control">
                        <label for="">Products Images</label>

                        <input type="file" accept="image/*" class="form-control" name="product_images[]" multiple>

                    </div>


                <div class="form-group">
                    <button type="submit" class="btn btn-success"><?php echo e(isset($product) ? "Update Product": "Create a new product"); ?></button>
                </div>

                    <?php if(isset($product)): ?>
               <div class="imagesContainer">

                   <?php $__currentLoopData = explode(",",$product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($image !== ""): ?>
                     <img src="<?php echo e(asset($image)); ?>" height="100px" width="100px"/>
                     <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>
                        <?php endif; ?>
            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/dashboard/product/create.blade.php ENDPATH**/ ?>