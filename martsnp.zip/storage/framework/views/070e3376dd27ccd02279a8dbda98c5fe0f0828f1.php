<?php $__env->startSection('content'); ?>

    

    <div class="card">
        <div class="card-header font-24">
            Store
        </div>
        <div class="card-body">

            <a href="<?php echo e(route('stores.create')); ?>" class="btn btn-success">Create a new store</a>

        </div>
    </div>


    <div class="row">
        <!-- column -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <!-- title -->
                    <div class="d-md-flex align-items-center">
                        <div>
                            <h4 class="card-title">All stores list</h4>

                        </div>

                    </div>
                    <!-- title -->




                </div>
                <div class="table-responsive">
                    <table class="table v-middle">
                        <thead>
                        <tr class="bg-light">

                            <th class="border-top-0">Name</th>
                            <th class="border-top-0">Subscription Limit</th>
                            <th class="border-top-0">Remaining Days</th>
                            <th class="border-top-0">image</th>
                            <th class="border-top-0">Store Type</th>
                            <th class="border-top-0">Total_products</th>
                            <th class="border-top-0">Open</th>
                            <th class="border-top-0">Edit</th>

                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>





                            <tr>
                                <td><?php echo e($store->name); ?></td>

                                <td><?php echo e($store->seller()->end_limit); ?> days</td>



                                <td><?php echo e($store->remainingSubscription()); ?></td>

                                <td><img src="<?php echo e(asset($store->store_image)); ?>" alt="" height="40px" width="40px"></td>
                                <td><?php echo e(str_replace("-"," ",$store->store_type)); ?></td>
                                <td><?php echo e($store->products->count()); ?></td>
                                <td><a href="<?php echo e(route('storeProduct',$store->slug)); ?>" class="btn btn-xs btn-success">Open</a></td>

                                <td><a href="<?php echo e(route('stores.edit',$store->id)); ?>" class="btn btn-xs btn-default">Edit</a></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/dashboard/store/index.blade.php ENDPATH**/ ?>