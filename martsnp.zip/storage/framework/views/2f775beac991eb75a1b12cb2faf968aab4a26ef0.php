<?php $__env->startSection("title"); ?>
    martSNP- Get free online store| Sell And Buy
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <!-- Product -->
    <!-- ================================ Slider ==========================  -->
    <?php echo $__env->make("components.slider", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
    <?php echo $__env->make("components.banner", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="sec-product bg0 p-t-20 p-b-50">
        <div class="container">


            <!-- ======= Services Section ======= -->
            <section id="services" class="services">
                <div class="container">





                    <div class="row d-flex ">

                        <?php $__currentLoopData = $store_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e(route('specific-stores',$type->slug)); ?>" class="col-lg-4 btn-style col-md-6 d-flex align-items-stretch m-tb--5 p-b-100 align-self-center ">
                           <div class="image-container m-l-auto m-r-auto" style='font-family: "Nunito", sans-serif;'>
                               <img  src="<?php echo e(asset($type->image)); ?>" width="250px" height="250px" alt="">

                               <div style="text-align:center;  font-family: Poppins-Medium; color:black; box-shadow: 0 0px 1px 1px rgba(211,211,211,.55); padding:20px;"><?php echo e($type->store_type); ?></div>

                           </div>

                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




































































                    </div>


                </div>
            </section>



            <div>






































            </div>





        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("css"); ?>
    <style>
        .btn-style{
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/index.blade.php ENDPATH**/ ?>