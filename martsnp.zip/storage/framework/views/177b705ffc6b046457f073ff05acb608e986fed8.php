<?php $__env->startSection("title"); ?>

    martSNP- <?php echo e(isset($store_name) ? $store_name : "Store"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
    <div class="bg0 m-t-23 p-b-140">
        <div class="container">
            <div class="flex-w flex-sb-m p-b-52">
                <div class="flex-w flex-l-m filter-tope-group m-tb-10">
                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1" data-filter="*">
                       Products Related To
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".women">
                        Men
                    </button>
                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".women">
                        Women
                    </button>
                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".women">
                        Others
                    </button>


                </div>
            </div>

           <div style="text-align: center;"> <h2><?php echo e(isset($store_name) ? $store_name : "Store"); ?></h2></div>
            <br>
    <div class="row isotope-grid">

        <?php if($products->count() > 0): ?>

            <span style="visibility: hidden;">

                <?php echo e($show_buy_btn = false); ?>

                            </span>



            <?php echo $__env->make("partials.product_item", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



         <?php else: ?>
            <div>No content is found</div>
        <?php endif; ?>



        








    </div>
        </div>



    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/front/store/product.blade.php ENDPATH**/ ?>