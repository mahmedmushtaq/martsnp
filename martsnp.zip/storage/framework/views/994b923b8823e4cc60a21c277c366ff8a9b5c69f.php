<?php $__env->startSection("title"); ?>

    martSNP- stores
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>


    <section class="sec-product bg0 p-t-100 p-b-50">
        <div class="container">
            <div class="p-b-32">
                <h3 class="ltext-105 cl5 txt-center respon1">
                    Store Overview
                </h3>
            </div>

            <!-- Tab01 -->
            <div class="tab01">
                <!-- Nav tabs -->


                <!-- Tab panes -->
                <div class="tab-content p-t-50">
                    <!-- - -->
                    <div class="tab-pane fade show active" id="best-seller" role="tabpanel">
                        <!-- Slide2 -->
                        <div class="row isotope-grid">







                            <?php echo $__env->make("partials.store_item", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






                            </div>
                        </div>
                    </div>

                <?php echo e($stores->links()); ?>

            </div>










        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/stores-overview.blade.php ENDPATH**/ ?>