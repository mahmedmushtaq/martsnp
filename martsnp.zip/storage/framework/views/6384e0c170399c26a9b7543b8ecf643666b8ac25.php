<?php $__env->startSection('content'); ?>

    

    <div class="card">
        <div class="card-header font-24">
            Products
        </div>
        <div class="card-body">

            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success">Create a new product</a>

        </div>
    </div>


    <div class="row">
        <!-- column -->
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <!-- title -->
                    <div class="d-md-flex align-items-center">
                        <div>
                            <h4 class="card-title">All Posts list</h4>

                        </div>

                    </div>
                    <!-- title -->
                </div>
                <div class="table-responsive">
                    <table class="table v-middle">
                        <thead>
                        <tr class="bg-light">
                            <th class="border-top-0">Name</th>
                            <th class="border-top-0">Store Name</th>
                            <th class="border-top-0">Category</th>
                            <th class="border-top-0">Open</th>
                            <th class="border-top-0">Edit</th>
                            <th class="border-top-0">Delete</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->store->name); ?></td>
                                <td><?php echo e($product->category_name === 'both' ? "Both male and female" : $product->category_name); ?></td>
                                <td><a href="<?php echo e(route('productdetails',$product->slug)); ?>" class="btn xs btn-success">Open</a></td>
                                <td><a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-small btn-default">Edit</a></td>
                                <td><form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST" >
                                        <?php echo method_field("DELETE"); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-small btn-danger">Delete</button>

                                    </form></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>

                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/dashboard/product/index.blade.php ENDPATH**/ ?>