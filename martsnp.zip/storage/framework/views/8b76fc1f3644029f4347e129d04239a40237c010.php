<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-header font-24">
           <?php echo e(isset($store) ? "Edit store" : "Add A New Store"); ?>

        </div>
        <div class="card-body">
            <?php echo $__env->make("partials.error", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <form action="<?php echo e(isset($store) ? route("stores.update",$store->id) :route("stores.store")); ?>" method="POST" enctype="multipart/form-data">
                <?php if(isset($store)): ?>
                    <?php echo method_field("PUT"); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Store Name" name="name" value="<?php echo e(isset($store)? $store->name : ""); ?>">
                </div>

                    <div class="form-group">
                        <label for="">Store Type <small>(e.g Store for men's or women's clothes,electronics or others)</small></label>

                        <select name="store_type" id="" class="form-control">
                          <?php $__currentLoopData = $store_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->slug); ?>"<?php if(isset($store)): ?><?php echo e($store->store_type === $type->slug ? 'selected' : ""); ?><?php endif; ?>><?php echo e($type->store_type); ?></option>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Store image</label>
                        <input type="file" class="form-control"  name="store_image" >
                    </div>
                    <?php if(isset($store)): ?>
                        <img src="<?php echo e(asset($store->store_image)); ?>" alt="" height="100px" width="100px">
                        <br>    <br>
                    <?php endif; ?>



                <div class="form-group">
                    <button type="submit" class="btn btn-success"><?php echo e(isset($store) ? "Update store": "Create a new store"); ?></button>
                </div>


            </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/dashboard/store/create.blade.php ENDPATH**/ ?>