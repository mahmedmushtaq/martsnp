<div class="wrap-header-cart js-panel-cart">
    <div class="s-full js-hide-cart"></div>

   <span style="visibility: hidden">
        <?php echo e($value = 0); ?>

   </span>
    <div class="header-cart flex-col-l p-l-65 p-r-25">
        <div class="header-cart-title flex-w flex-sb-m p-b-8">
				<span class="mtext-103 cl2">
					Your Cart
				</span>

            <div class="fs-35 lh-10 cl2 p-lr-5 pointer hov-cl1 trans-04 js-hide-cart">
                <i class="zmdi zmdi-close"></i>
            </div>
        </div>

        <div class="header-cart-content flex-w js-pscroll">
            <ul class="header-cart-wrapitem w-full">

                <?php if(isset($cartData)): ?>
                <?php $__currentLoopData = $cartData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li class="header-cart-item flex-w flex-t m-b-12">
                    <div class="header-cart-item-img">
                        <img src="<?php echo e(asset($cart->single_image)); ?>" alt="IMG">

                    </div>

                    <div class="header-cart-item-txt p-t-8">
                        <a href="#" class="header-cart-item-name m-b-18 hov-cl1 trans-04">
                           <?php echo e($cart->name); ?>

                        </a>

                        <span class="header-cart-item-info">
								<?php echo e($cart->qty); ?> x <?php echo e($cart->price); ?>

							</span>

                    </div>

                    <form action="<?php echo e(route('cart.destroy',$cart->rawId())); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                        <div class="wrap-num-product flex-w m-r-20 m-tb-10">

                            <button type="submit" name="decrease" value="decrease" class="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
                                <i class="fs-16 zmdi zmdi-minus"></i>
                            </button>

                            <input class="mtext-104 cl3 txt-center num-product" type="number" name="cart_quantity" value="<?php echo e($cart->qty); ?>">

                        <button name="increase" type="submit" value="increase"  class="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
                            <i class="fs-16 zmdi zmdi-plus"></i>

                        </button>




                        </div>

                        <button name="remove_item" type="submit" value="remove_item" class="flex-c-m stext-101 cl0 size-107 bg1 bor2 hov-btn3 p-lr-15 trans-04 m-b-10">Remove </button>

                        <span style="visibility: hidden;">
                           <?php echo e($value += $cart->qty * $cart->price); ?>

                        </span>


                    </form>





                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>




            </ul>

            <div class="w-full">
                <?php if(isset($cartData)): ?>
                <div class="header-cart-total w-full p-tb-40">
                    Total
                   Rs   <?php echo e($value); ?>

                </div>
               <?php endif; ?>

                <div class="header-cart-buttons flex-w w-full">


                    <a href="<?php echo e(route('cart.index')); ?>" class="flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-b-10">
                        Check Out
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startSection("scripts"); ?>
    <script>
        const increaseValue = ()=>{
            console.log("onclick occur");
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\martsnp\resources\views/components/cart.blade.php ENDPATH**/ ?>