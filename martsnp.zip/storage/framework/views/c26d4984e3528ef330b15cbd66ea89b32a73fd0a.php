<?php $__env->startSection("title"); ?>

    martSNP- All Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
    <div class="bg0 m-t-23 p-b-140">
        <div class="container">
            <div class="flex-w flex-sb-m p-b-52">
                <div class="flex-w flex-l-m filter-tope-group m-tb-10">
                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1" data-filter="*">
                        All Products
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".women">
                        Women
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".men">
                        Men
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".bag">
                        Bag
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".shoes">
                        Shoes
                    </button>

                    <button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5" data-filter=".watches">
                        Watches
                    </button>
                </div>






            </div>




            <div class="row  isotope-grid ml-auto mr-auto" >



                   <span style="visibility: hidden;">

                                <?php echo e($show_buy_btn = true); ?>

                            </span>



               <?php echo $__env->make("partials.product_item", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






            </div>


            <!-- Load more -->
            <div class="flex-c-m flex-w w-full p-t-45">
                <?php if(isset($products)): ?>
                    <?php echo e($products->links()); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.base", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\martsnp\resources\views/products-overview.blade.php ENDPATH**/ ?>