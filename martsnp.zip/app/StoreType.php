<?php

namespace App;



class StoreType extends Model
{
    //
}
